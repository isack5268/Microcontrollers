<?php
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "/lib/module/ui-main-menu.php";
   include_once($path);
?>